// Login form submission
document.getElementById("login-form").addEventListener("submit", function(event) {
	event.preventDefault();
	var username = document.getElementById("username").value;
	var password = document.getElementById("password").value;
	// Send username and password to server for authentication
	// If successful, redirect to main page
	// If unsuccessful, display error message
	console.log("Login submitted with username: " + username + " and password: " + password);
});

// Register form submission
document.getElementById("register-form").addEventListener("submit", function(event) {
	event.preventDefault();
	var username = document.getElementById("username").value;
	var email = document.getElementById("email").value;
	var password = document.getElementById("password").value;
	var confirmPassword = document.getElementById("confirm-password").value;
	// Validate form data
	// If valid, send data to server to create new account
	// If unsuccessful, display error message
	console.log("Register submitted with username: ")})
